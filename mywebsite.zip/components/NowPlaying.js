import useSWR from 'swr';

import fetcher from '../lib/fetcher';

export default function NowPlaying() {
  const { data } = useSWR('/api/now-playing', fetcher, { refreshInterval: 10000 });

  return (
    <div className="spotify">
      {data?.songUrl ? (
      <svg className="logo" viewBox="0 0 168 168">
        <path
          fill="#1ED760"
          d="M83.996.277C37.747.277.253 37.77.253 84.019c0 46.251 37.494 83.741 83.743 83.741 46.254 0 83.744-37.49 83.744-83.741 0-46.246-37.49-83.738-83.745-83.738l.001-.004zm38.404 120.78a5.217 5.217 0 01-7.18 1.73c-19.662-12.01-44.414-14.73-73.564-8.07a5.222 5.222 0 01-6.249-3.93 5.213 5.213 0 013.926-6.25c31.9-7.291 59.263-4.15 81.337 9.34 2.46 1.51 3.24 4.72 1.73 7.18zm10.25-22.805c-1.89 3.075-5.91 4.045-8.98 2.155-22.51-13.839-56.823-17.846-83.448-9.764-3.453 1.043-7.1-.903-8.148-4.35a6.538 6.538 0 014.354-8.143c30.413-9.228 68.222-4.758 94.072 11.127 3.07 1.89 4.04 5.91 2.15 8.976v-.001zm.88-23.744c-26.99-16.031-71.52-17.505-97.289-9.684-4.138 1.255-8.514-1.081-9.768-5.219a7.835 7.835 0 015.221-9.771c29.581-8.98 78.756-7.245 109.83 11.202a7.823 7.823 0 012.74 10.733c-2.2 3.722-7.02 4.949-10.73 2.739z"
        />
      </svg>
      ):(` `)}
      <div className="songtext">
        {data?.songUrl ? (
          <a
            className=""
            href={data.songUrl}
            target="_blank"
            rel="noopener noreferrer"
          >
            {data.title}
          </a>
        ) : (
          <p className="">
            
          </p>
        )}
        <span className="line">
        {data?.songUrl ? (`
           – 
          `) : (` `)}
        </span>
        <p className="">
          {data?.artist ?? ''}
        </p>
        {data?.albumImageUrl ? (
        <style jsx global>{`
            body {
                background: #000;
                background: url(${data?.albumImageUrl})no-repeat center center;
                background-size: cover;
            }
            .spotify {
                position: absolute;
                right: 20px;
                top: 20px;
                color: #fff;
                filter: blur(.5px);
                flex-direction: row;
              }
              .spotify .songtext {
                display: inline-flex;
              }
              .spotify .line {
                display: block;
                margin-left: .5rem;
                margin-right: .5rem;
              }
              .spotify * {
                flex-direction: row;
                margin: 0;
              }
              .spotify div {
                display: flex;
              }
              .spotify .logo {
                height: 1rem;
                width: 1rem;
                margin-top: .25rem;
                margin-right: .50rem;
                position: relative;
                top: 3px;
              }
        `}</style>
        ): (
            <style jsx global>{`
            body {
                background: #1A2141;
                background-image: linear-gradient( 94.3deg,  rgba(26,33,64,1) 10.9%, rgba(81,84,115,1) 87.1% );
            }
            .spotify {
                position: absolute;
                right: 20px;
                top: 20px;
                color: #fff;
                filter: blur(.5px);
                flex-direction: row;
              }
              .spotify .songtext {
                display: inline-flex;
              }
              .spotify .line {
                display: block;
                margin-left: .5rem;
                margin-right: .5rem;
              }
              .spotify * {
                flex-direction: row;
                margin: 0;
              }
              .spotify div {
                display: flex;
              }
              .spotify .logo {
                height: 1rem;
                width: 1rem;
                margin-top: .25rem;
                margin-right: .50rem;
                position: relative;
                top: 3px;
              }
        `}</style>
        )}
      </div>
    </div>
  );
}